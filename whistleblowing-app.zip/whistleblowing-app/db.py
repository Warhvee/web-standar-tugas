import sqlite3
from flask import g, current_app


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
        # WAL (Write-Ahead Logging) -- penting begitu diakses banyak pengguna sekaligus
        # (mis. hosting publik): pembaca (dashboard, hotspot) tidak lagi saling kunci-mengunci
        # dengan penulis (siswa submit laporan) seperti mode default SQLite.
        g.db.execute("PRAGMA journal_mode = WAL")
    return g.db


def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    nama TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('guru_bk', 'kepsek', 'tu'))
);

CREATE TABLE IF NOT EXISTS kelas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama_kelas TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS laporan (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kode_tiket TEXT UNIQUE NOT NULL,
    waktu_kejadian TEXT,
    kategori_waktu TEXT,              -- kategori terstruktur (utk analitik hotspot), terpisah dari waktu_kejadian bebas teks
    lokasi_kejadian TEXT,             -- kategori terkontrol (dropdown), lihat Config.LOKASI_KEJADIAN_OPSI
    lokasi_lainnya_detail TEXT,       -- detail bebas teks HANYA jika lokasi_kejadian = 'Lainnya'
    jenis_kekerasan TEXT,
    kronologi TEXT NOT NULL,
    nama_terduga_pelaku TEXT NOT NULL,
    kelas_terduga_pelaku TEXT NOT NULL,
    nis_terduga_pelaku TEXT,          -- opsional, diisi BK saat verifikasi -- lihat catatan di README soal akurasi pencocokan identitas
    bukti_filename TEXT,
    bukti_hash TEXT,                  -- SHA-256 dari file ASLI (dihitung sebelum diubah apa pun)
    bukti_watermark_filename TEXT,    -- salinan berstempel waktu, HANYA untuk tampilan/cetak -- bukan pengganti file asli
    bukti_upload_gagal INTEGER NOT NULL DEFAULT 0,  -- 1 = siswa MENCOBA unggah bukti tapi gagal tersimpan
                                                     -- (mis. disk server penuh) -- beda dgn "memang tidak ada bukti"
    darurat INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'Menunggu Verifikasi',
        -- alur status: Menunggu Verifikasi -> Diproses -> Mediasi -> Selesai
        --              atau -> Ditolak (tidak valid / spam)
    tingkat_pelanggaran TEXT,        -- Ringan / Sedang / Berat -- WAJIB diisi BK saat menutup kasus (aksi 'selesaikan')
    catatan_verifikasi TEXT,
    sanksi TEXT,
    catatan_mediasi TEXT,
    jadwal_mediasi TEXT,
    ip_hash TEXT NOT NULL,
    tanggal_masuk TEXT NOT NULL,
    tanggal_verifikasi TEXT,
    tanggal_selesai TEXT
);

CREATE TABLE IF NOT EXISTS notifikasi_ortu (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    laporan_id INTEGER NOT NULL REFERENCES laporan(id),
    pesan TEXT NOT NULL,
    metode TEXT NOT NULL,
    status_kirim TEXT NOT NULL,
    waktu_kirim TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS edukasi (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    judul TEXT NOT NULL,
    ringkasan TEXT NOT NULL,
    isi TEXT NOT NULL,
    penulis TEXT,
    tanggal_terbit TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS log_akses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER REFERENCES users(id),
    laporan_id INTEGER REFERENCES laporan(id),
    aksi TEXT NOT NULL,
    waktu TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rate_limit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ip_hash TEXT NOT NULL,
    waktu TEXT NOT NULL
);

-- ---------------------------------------------------------------------------
-- GERBANG PERSETUJUAN SKBB (Human-in-the-Loop, BUKAN pemblokiran otomatis)
-- Satu baris = satu "flag" yang dipicu oleh satu kasus BERAT yang sudah Selesai.
-- Status akhirnya SELALU ditentukan manusia (Kepsek/Guru BK), sistem hanya
-- mencatat & menyajikan -- lihat README bagian "Gerbang Persetujuan SKBB".
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS status_skbb (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    laporan_id INTEGER NOT NULL REFERENCES laporan(id),
    nama_siswa TEXT NOT NULL,
    kelas_siswa TEXT NOT NULL,
    nis_siswa TEXT,
    status TEXT NOT NULL DEFAULT 'Menunggu Persetujuan',
        -- 'Menunggu Persetujuan' | 'Disetujui Sementara' | 'Ditolak' | 'Direhabilitasi'
    catatan TEXT,                 -- alasan wajib diisi setiap kali status berubah
    diputuskan_oleh INTEGER REFERENCES users(id),
    waktu_keputusan TEXT,
    dibuat_pada TEXT NOT NULL
);
"""


def init_db():
    db = get_db()
    db.executescript(SCHEMA)
    db.commit()
