import os
import secrets

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
INSTANCE_DIR = os.path.join(BASE_DIR, "instance")
SECRET_KEY_FILE = os.path.join(INSTANCE_DIR, "secret_key.txt")


def _muat_atau_buat_secret_key():
    """Setiap instalasi otomatis mendapat kunci rahasia unik & acak, tersimpan
    lokal di instance/secret_key.txt -- TIDAK ditulis langsung di kode sumber.

    Kenapa ini penting: SECRET_KEY dipakai Flask untuk menandatangani cookie
    sesi login. Kode ini akan disebarluaskan (mis. dilampirkan ke laporan PKM,
    diunggah ke GitHub) -- kalau kuncinya tertulis statis di kode, SIAPA PUN
    yang membaca kode sumber publik bisa memalsukan cookie sesi dan login
    sebagai Guru BK/Kepala Sekolah/TU tanpa password sama sekali. Dengan
    di-generate otomatis per instalasi, sekolah tidak perlu (dan tidak mungkin
    lupa) mengedit apa pun secara manual demi ini tetap aman.
    """
    os.makedirs(INSTANCE_DIR, exist_ok=True)
    if os.path.exists(SECRET_KEY_FILE):
        with open(SECRET_KEY_FILE, "r") as f:
            key = f.read().strip()
            if key:
                return key
    key = secrets.token_hex(32)
    with open(SECRET_KEY_FILE, "w") as f:
        f.write(key)
    return key


class Config:
    SECRET_KEY = _muat_atau_buat_secret_key()
    DATABASE = os.path.join(BASE_DIR, "instance", "whistleblowing.db")

    # Sengaja DILUAR folder static/ -- supaya bukti tidak bisa diakses lewat URL
    # statis biasa (/static/uploads/...) tanpa login. Satu-satunya jalur resmi
    # untuk membuka file ini adalah route /bk/bukti/<filename> yang mewajibkan
    # login sebagai Guru BK (lihat app.py: bk_bukti_file()).
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "secure_uploads")

    MAX_CONTENT_LENGTH = 8 * 1024 * 1024  # maks 8 MB per file bukti (akan dikompres otomatis ke ukuran jauh lebih kecil)
    ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "pdf"}

    # --- Manajemen kapasitas penyimpanan (Digital Evidence Vault) ---
    # Foto bukti otomatis dikompres & diperkecil resolusinya SEBELUM disimpan ke disk,
    # supaya siswa tidak perlu repot mengompres manual, dan server tidak cepat penuh
    # walau menerima banyak foto beresolusi tinggi dari kamera HP modern.
    MAX_DIMENSI_GAMBAR_PX = 1920   # sisi terpanjang foto, setelah ini baru diperkecil
    KUALITAS_JPEG_BUKTI = 85       # 0-100 -- 85 masih tajam utk dibaca teks chat, ukuran jauh lebih kecil

    # Ambang peringatan dini di dashboard BK (dalam MB) -- sesuaikan dengan kapasitas
    # disk hosting yang sebenarnya dibeli sekolah (mis. kalau paket 2 GB, set ke ~1500).
    STORAGE_WARNING_MB = 1500

    # Nama sekolah -- bisa di-override lewat environment variable NAMA_SEKOLAH saat deploy,
    # tanpa perlu mengedit kode sumber (praktik konfigurasi produksi yang lebih rapi)
    NAMA_SEKOLAH = os.environ.get("NAMA_SEKOLAH", "SMP/SMA Contoh")

    # SOP: batas waktu (dalam hari) sesuai rancangan SOP
    SLA_VERIFIKASI_HARI = 2
    SLA_KEPUTUSAN_HARI = 5

    # Rate limit anti-spam: maksimal N laporan per IP dalam X menit
    RATE_LIMIT_MAKS = 3
    RATE_LIMIT_MENIT = 60

    MIN_KATA_KRONOLOGI = 50

    # --- Kategori terkontrol untuk Analitik Titik Rawan (Hotspot) ---
    # "Lainnya" WAJIB selalu jadi opsi terakhir -- dipakai sebagai jaring pengaman
    # (misal cyberbullying tidak selalu punya lokasi fisik) dan sebagai bucket
    # otomatis untuk data lama yang lokasinya masih bebas/tidak baku.
    LOKASI_KEJADIAN_OPSI = [
        "Kantin",
        "Toilet",
        "Lorong/Koridor Kelas",
        "Ruang Kelas",
        "Lapangan/Halaman Sekolah",
        "Belakang Sekolah/Area Terpencil",
        "Media Sosial/Online (Cyberbullying)",
        "Lainnya",
    ]
    KATEGORI_WAKTU_OPSI = [
        "Sebelum Jam Pelajaran",
        "Saat Jam Pelajaran Berlangsung",
        "Istirahat Pertama",
        "Istirahat Kedua",
        "Pulang Sekolah",
        "Lainnya/Tidak Menentu",
    ]

    # Ambang jumlah laporan minimum sebelum statistik hotspot dianggap cukup solid
    # untuk dijadikan dasar kebijakan (mis. pasang CCTV). Di bawah ini, dashboard
    # akan menampilkan peringatan "data masih terbatas".
    HOTSPOT_MIN_SAMPEL = 10
    # Sel kombinasi lokasi x waktu dengan jumlah di bawah ini disamarkan (tidak
    # ditampilkan angka pastinya) untuk mencegah kombinasi data yang terlalu
    # spesifik berpotensi mengarah ke identifikasi kasus tertentu.
    HOTSPOT_SEL_MIN_TAMPIL = 3

    # --- Tingkat pelanggaran (WAJIB diisi BK saat menutup kasus) ---
    TINGKAT_PELANGGARAN_OPSI = ["Ringan", "Sedang", "Berat"]

    # Tingkat pelanggaran yang memicu Gerbang Persetujuan SKBB (lihat README).
    # Sengaja hanya "Berat" -- bukan pemblokiran otomatis untuk semua kasus.
    TINGKAT_PEMICU_SKBB = "Berat"

    # --- Notifikasi Orang Tua ---
    # Pilihan MODE_NOTIFIKASI:
    #   "simulasi"         -> default, aman, gratis, tidak butuh kredensial apapun (cocok utk demo PKM)
    #   "email_smtp"       -> kirim email sungguhan (butuh akun SMTP, mis. Gmail App Password)
    #   "whatsapp_fonnte"  -> kirim WhatsApp sungguhan via Fonnte (butuh token, lihat README bagian WhatsApp)
    MODE_NOTIFIKASI = os.environ.get("MODE_NOTIFIKASI", "simulasi")

    # -- Email (dipakai jika MODE_NOTIFIKASI = "email_smtp") --
    # Dibaca dari environment variable, BUKAN ditulis langsung di sini -- supaya kredensial
    # asli sekolah tidak pernah ikut ter-commit kalau kode ini diunggah ke repo publik
    # (mis. GitHub untuk lampiran PKM). Saat demo lokal, cukup dibiarkan kosong seperti ini.
    SMTP_HOST = os.environ.get("SMTP_HOST", "")
    SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
    SMTP_USER = os.environ.get("SMTP_USER", "")
    SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "")

    # -- WhatsApp via Fonnte (dipakai jika MODE_NOTIFIKASI = "whatsapp_fonnte") --
    # 1. Daftar gratis di https://fonnte.com dan scan QR untuk hubungkan nomor WA sekolah
    # 2. Salin "Token" dari dashboard Fonnte, set sebagai environment variable FONNTE_TOKEN
    FONNTE_TOKEN = os.environ.get("FONNTE_TOKEN", "")

    # --- PWA (Progressive Web App) ---
    # Nama SENGAJA dibuat netral/generik, bukan "Lapor Bullying" dsb -- supaya ikon & nama
    # di home screen HP siswa tidak membocorkan bahwa mereka memakai aplikasi pelaporan
    # perundungan kalau layar HP-nya dilihat orang lain (mis. pelaku atau orang tua pelaku).
    PWA_APP_NAME = "Portal BK Sekolah"
    PWA_SHORT_NAME = "Portal BK"
    PWA_DESCRIPTION = "Portal informasi dan layanan Bimbingan Konseling sekolah."
