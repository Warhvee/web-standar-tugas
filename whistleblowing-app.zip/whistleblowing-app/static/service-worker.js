/*
 * Service Worker -- Sistem Whistleblowing Anti-Perundungan
 *
 * PRINSIP KEAMANAN (baca sebelum mengubah file ini):
 * Aplikasi ini menangani data sensitif (laporan perundungan, identitas terduga pelaku,
 * dashboard Guru BK/Kepala Sekolah). Service worker TIDAK BOLEH menyimpan halaman-halaman
 * tersebut ke cache, karena cache tersimpan di penyimpanan lokal perangkat dan bisa saja
 * diakses siapa pun yang memegang HP/laptop tersebut, bahkan tanpa login ulang.
 *
 * Yang di-cache HANYA aset statis tak-sensitif: CSS, ikon, dan halaman offline generik.
 * Semua halaman dinamis (form lapor, dashboard BK, dashboard Kepsek, login, cek status)
 * SELALU diambil langsung dari server (network-only / network-first), tidak pernah dari cache.
 */

const CACHE_NAME = "wbs-static-v1";

const PRECACHE_URLS = [
  "/static/css/style.css",
  "/static/icons/icon-192.png",
  "/static/icons/icon-512.png",
  "/offline.html",
];

// Prefix halaman yang TIDAK PERNAH boleh disentuh cache -- selalu network-only.
const NEVER_CACHE_PREFIXES = [
  "/bk/", "/kepsek/", "/tu/", "/login", "/logout", "/lapor", "/cek-status",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(PRECACHE_URLS))
      .catch(() => { /* offline saat instal pertama kali -- tidak fatal, coba lagi nanti */ })
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

function bolehDicache(pathname) {
  return !NEVER_CACHE_PREFIXES.some((prefix) => pathname.startsWith(prefix));
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // Hanya tangani GET dari origin sendiri. Selain itu, biarkan browser proses seperti biasa
  // (termasuk semua request POST -- form lapor, login, dsb -- TIDAK PERNAH lewat cache).
  if (req.method !== "GET" || url.origin !== self.location.origin) return;

  // Halaman sensitif: selalu ambil dari server, tanpa singgah ke cache sama sekali.
  if (!bolehDicache(url.pathname)) {
    event.respondWith(
      fetch(req).catch(() => caches.match("/offline.html"))
    );
    return;
  }

  // Aset statis (CSS, ikon, manifest): cache-first supaya cepat & hemat kuota data siswa.
  if (url.pathname.startsWith("/static/") || url.pathname === "/manifest.json") {
    event.respondWith(
      caches.match(req).then((cached) => {
        if (cached) return cached;
        return fetch(req).then((resp) => {
          const clone = resp.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
          return resp;
        });
      })
    );
    return;
  }

  // Halaman publik lain (beranda, edukasi, papan kehormatan): network-first,
  // fallback ke cache/offline HANYA jika benar-benar tidak ada koneksi sama sekali.
  event.respondWith(
    fetch(req)
      .then((resp) => {
        const clone = resp.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
        return resp;
      })
      .catch(() =>
        caches.match(req).then((cached) => cached || caches.match("/offline.html"))
      )
  );
});
