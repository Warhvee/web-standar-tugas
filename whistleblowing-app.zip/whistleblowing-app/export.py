"""
Modul ekspor dokumen: Excel (openpyxl) dan PDF (reportlab).
Dipisah dari app.py agar logika tampilan & logika ekspor tidak bercampur.
"""
import io
import os
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, HRFlowable,
    Image as RLImage,
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT

BIRU_TUA = colors.HexColor("#12325C")
BIRU = colors.HexColor("#1C5AA6")
TEAL = colors.HexColor("#0E9384")
ABU = colors.HexColor("#5A6473")
ABU_MUDA = colors.HexColor("#F4F6F8")
MERAH = colors.HexColor("#C0392B")

_BULAN_ID = {
    1: "Januari", 2: "Februari", 3: "Maret", 4: "April", 5: "Mei", 6: "Juni",
    7: "Juli", 8: "Agustus", 9: "September", 10: "Oktober", 11: "November", 12: "Desember",
}


def _tanggal_indonesia(dt=None):
    """Format tanggal ke Bahasa Indonesia tanpa bergantung pada locale sistem
    (locale 'id_ID' seringkali tidak terpasang di server/laptop sekolah)."""
    dt = dt or datetime.now()
    return f"{dt.day:02d} {_BULAN_ID[dt.month]} {dt.year}, {dt.strftime('%H:%M')}"


# =====================================================================================
# EXCEL
# =====================================================================================

def _style_header_row(ws, row_idx, n_cols, fill_hex="12325C"):
    fill = PatternFill(start_color=fill_hex, end_color=fill_hex, fill_type="solid")
    font = Font(color="FFFFFF", bold=True)
    for c in range(1, n_cols + 1):
        cell = ws.cell(row=row_idx, column=c)
        cell.fill = fill
        cell.font = font
        cell.alignment = Alignment(vertical="center", wrap_text=True)


def _autofit(ws, widths):
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w


def buat_excel_laporan(rows, nama_sekolah):
    """Ekspor seluruh data laporan (untuk Guru BK) -- termasuk detail sensitif,
    karena file ini ditujukan untuk dokumentasi internal, bukan disebarluaskan."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Rekap Laporan"

    ws.merge_cells("A1:O1")
    ws["A1"] = f"Rekap Laporan Perundungan -- {nama_sekolah}"
    ws["A1"].font = Font(bold=True, size=14, color="12325C")
    ws.merge_cells("A2:O2")
    ws["A2"] = f"Diunduh pada: {_tanggal_indonesia()} WIB"
    ws["A2"].font = Font(italic=True, size=10, color="5A6473")
    ws.merge_cells("A3:O3")
    ws["A3"] = "RAHASIA -- hanya untuk keperluan internal sekolah. Jangan disebarluaskan."
    ws["A3"].font = Font(italic=True, size=10, color="C0392B")

    header_row = 5
    headers = [
        "Kode Tiket", "Tanggal Masuk", "Status", "Darurat", "Jenis Kekerasan",
        "Waktu Kejadian", "Kategori Waktu", "Lokasi", "Detail Lokasi Lainnya",
        "Terduga Pelaku", "Kelas", "NIS", "Tingkat Pelanggaran", "Sanksi", "Tanggal Selesai",
    ]
    for i, h in enumerate(headers, start=1):
        ws.cell(row=header_row, column=i, value=h)
    _style_header_row(ws, header_row, len(headers))

    thin = Side(style="thin", color="DDDDDD")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    for r, row in enumerate(rows, start=header_row + 1):
        values = [
            row["kode_tiket"], row["tanggal_masuk"], row["status"],
            "YA" if row["darurat"] else "-", row["jenis_kekerasan"] or "-",
            row["waktu_kejadian"] or "-", row["kategori_waktu"] or "-",
            row["lokasi_kejadian"] or "-", row["lokasi_lainnya_detail"] or "-",
            row["nama_terduga_pelaku"], row["kelas_terduga_pelaku"], row["nis_terduga_pelaku"] or "-",
            row["tingkat_pelanggaran"] or "-", row["sanksi"] or "-",
            row["tanggal_selesai"] or "-",
        ]
        for c, v in enumerate(values, start=1):
            cell = ws.cell(row=r, column=c, value=v)
            cell.border = border
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            if r % 2 == 0:
                cell.fill = PatternFill(start_color="F4F6F8", end_color="F4F6F8", fill_type="solid")

    ws.freeze_panes = f"A{header_row + 1}"
    _autofit(ws, [14, 16, 16, 9, 22, 20, 20, 16, 20, 20, 10, 14, 16, 26, 16])

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def buat_excel_rekap(stats, nama_sekolah):
    """Ekspor rekap agregat (untuk Kepala Sekolah) -- HANYA data agregat, tanpa identitas pelapor."""
    wb = Workbook()

    ws1 = wb.active
    ws1.title = "Ringkasan"
    ws1.merge_cells("A1:B1")
    ws1["A1"] = f"Rekapitulasi Bulanan -- {nama_sekolah}"
    ws1["A1"].font = Font(bold=True, size=14, color="12325C")
    ws1.merge_cells("A2:B2")
    ws1["A2"] = f"Periode: {stats['bulan_ini']}  |  Diunduh: {_tanggal_indonesia()} WIB"
    ws1["A2"].font = Font(italic=True, size=10, color="5A6473")

    row = 4
    ws1.cell(row=row, column=1, value="Metrik")
    ws1.cell(row=row, column=2, value="Nilai")
    _style_header_row(ws1, row, 2)
    row += 1
    metrik = [
        ("Total Laporan Bulan Ini", stats["total_bulan_ini"]),
        ("Tingkat Penyelesaian Kasus", f"{stats['tingkat_penyelesaian']}%"),
    ]
    for s in stats["per_status"]:
        metrik.append((f"Status: {s['status']}", s["c"]))
    for label, val in metrik:
        ws1.cell(row=row, column=1, value=label)
        ws1.cell(row=row, column=2, value=val)
        row += 1
    _autofit(ws1, [32, 18])

    ws2 = wb.create_sheet("Tren 6 Bulan")
    ws2.cell(row=1, column=1, value="Bulan")
    ws2.cell(row=1, column=2, value="Jumlah Laporan")
    _style_header_row(ws2, 1, 2)
    for i, b in enumerate(stats["bulanan"], start=2):
        ws2.cell(row=i, column=1, value=b["bulan"])
        ws2.cell(row=i, column=2, value=b["jumlah"])
    _autofit(ws2, [16, 18])

    ws3 = wb.create_sheet("Top 5 Kelas")
    ws3.cell(row=1, column=1, value="Kelas")
    ws3.cell(row=1, column=2, value="Jumlah Laporan (Sepanjang Waktu)")
    _style_header_row(ws3, 1, 2)
    for i, k in enumerate(stats["per_kelas"], start=2):
        ws3.cell(row=i, column=1, value=k["kelas"])
        ws3.cell(row=i, column=2, value=k["c"])
    _autofit(ws3, [16, 30])

    ws4 = wb.create_sheet("Titik Rawan (Hotspot)")
    ws4.merge_cells("A1:D1")
    ws4["A1"] = "Titik Rawan Perundungan (Sepanjang Waktu, Laporan Tervalidasi)"
    ws4["A1"].font = Font(bold=True, size=12, color="12325C")
    if stats.get("sampel_kecil"):
        ws4.merge_cells("A2:D2")
        ws4["A2"] = (f"Peringatan: total data baru {stats['total_hotspot']} laporan (di bawah ambang "
                     f"{stats['hotspot_min_sampel']}) -- pola di bawah masih indikasi awal, belum cukup kuat "
                     f"untuk dasar kebijakan besar sendirian.")
        ws4["A2"].font = Font(italic=True, size=9, color="C0392B")
    hdr_row = 4
    ws4.cell(row=hdr_row, column=1, value="Lokasi")
    ws4.cell(row=hdr_row, column=2, value="Jumlah Laporan")
    ws4.cell(row=hdr_row, column=3, value="Persentase")
    ws4.cell(row=hdr_row, column=4, value="Tren Naik 2 Bulan Terakhir?")
    _style_header_row(ws4, hdr_row, 4)
    for i, h in enumerate(stats.get("hotspot_list", []), start=hdr_row + 1):
        ws4.cell(row=i, column=1, value=h["lokasi"])
        ws4.cell(row=i, column=2, value=h["jumlah"])
        ws4.cell(row=i, column=3, value=f"{h['persen']}%")
        ws4.cell(row=i, column=4, value="Ya" if h["tren_naik"] else "-")
    _autofit(ws4, [30, 16, 14, 24])

    if stats.get("kombinasi_list"):
        ws5 = wb.create_sheet("Kombinasi Lokasi-Waktu")
        ws5.cell(row=1, column=1, value="Lokasi")
        ws5.cell(row=1, column=2, value="Kategori Waktu")
        ws5.cell(row=1, column=3, value="Jumlah")
        _style_header_row(ws5, 1, 3)
        for i, k in enumerate(stats["kombinasi_list"], start=2):
            ws5.cell(row=i, column=1, value=k["lokasi"])
            ws5.cell(row=i, column=2, value=k["kategori_waktu"])
            ws5.cell(row=i, column=3, value=k["jumlah"] if k["tampilkan_angka"] else "Beberapa (data terbatas)")
        _autofit(ws5, [30, 26, 22])

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


# =====================================================================================
# PDF
# =====================================================================================

def _pdf_styles():
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="JudulDok", fontSize=17, textColor=BIRU_TUA, spaceAfter=4, fontName="Helvetica-Bold"))
    styles.add(ParagraphStyle(name="SubJudul", fontSize=10, textColor=ABU, spaceAfter=14, fontName="Helvetica-Oblique"))
    styles.add(ParagraphStyle(name="Rahasia", fontSize=9, textColor=MERAH, spaceAfter=14, fontName="Helvetica-Oblique"))
    styles.add(ParagraphStyle(name="H2", fontSize=13, textColor=BIRU, spaceBefore=14, spaceAfter=8, fontName="Helvetica-Bold"))
    styles.add(ParagraphStyle(name="BodyKecil", fontSize=10, leading=14, spaceAfter=8))
    styles.add(ParagraphStyle(name="Footer", fontSize=8, textColor=ABU, alignment=TA_CENTER))
    return styles


def _header_footer(canvas, doc, nama_sekolah):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(ABU)
    canvas.drawString(2 * cm, 1.3 * cm, f"{nama_sekolah} -- Sistem Whistleblowing Anti-Perundungan")
    canvas.drawRightString(A4[0] - 2 * cm, 1.3 * cm, f"Halaman {doc.page}")
    canvas.restoreState()


def _kv_table(pairs, col_widths=(5 * cm, 11 * cm)):
    data = [[Paragraph(f"<b>{k}</b>", getSampleStyleSheet()["Normal"]), Paragraph(str(v) if v else "-", getSampleStyleSheet()["Normal"])] for k, v in pairs]
    t = Table(data, colWidths=list(col_widths))
    t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#DDDDDD")),
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#F4F6F8")),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
    ]))
    return t


def buat_pdf_kasus(laporan, notifikasi, nama_sekolah, upload_folder=None):
    """Dokumentasi satu kasus lengkap (untuk arsip Guru BK / lampiran rapat dewan guru)."""
    buf = io.BytesIO()
    styles = _pdf_styles()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=2 * cm, bottomMargin=2 * cm, leftMargin=2 * cm, rightMargin=2 * cm)
    story = []

    story.append(Paragraph("Dokumentasi Penanganan Kasus Perundungan", styles["JudulDok"]))
    story.append(Paragraph(f"Kode Tiket: {laporan['kode_tiket']}  |  Status: {laporan['status']}", styles["SubJudul"]))
    story.append(Paragraph("RAHASIA -- dokumen ini memuat data sensitif dan hanya untuk kepentingan internal sekolah.", styles["Rahasia"]))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#DDDDDD"), spaceAfter=10))

    story.append(Paragraph("Detail Kejadian", styles["H2"]))
    lokasi_tampil = laporan["lokasi_kejadian"]
    if laporan["lokasi_kejadian"] == "Lainnya" and laporan["lokasi_lainnya_detail"]:
        lokasi_tampil = f"Lainnya -- {laporan['lokasi_lainnya_detail']}"
    story.append(_kv_table([
        ("Jenis Kekerasan", laporan["jenis_kekerasan"]),
        ("Waktu Kejadian", laporan["waktu_kejadian"]),
        ("Kategori Waktu", laporan["kategori_waktu"]),
        ("Lokasi", lokasi_tampil),
        ("Terduga Pelaku", f"{laporan['nama_terduga_pelaku']} ({laporan['kelas_terduga_pelaku']})"),
        ("NIS Terduga Pelaku", laporan["nis_terduga_pelaku"]),
        ("Ditandai Darurat", "Ya" if laporan["darurat"] else "Tidak"),
        ("Tanggal Laporan Masuk", laporan["tanggal_masuk"]),
    ]))
    story.append(Spacer(1, 10))

    story.append(Paragraph("Kronologi", styles["H2"]))
    story.append(Paragraph(laporan["kronologi"].replace("\n", "<br/>"), styles["BodyKecil"]))

    if laporan["bukti_filename"]:
        story.append(Paragraph("Bukti Terlampir (Digital Evidence Vault)", styles["H2"]))
        ditampilkan = False
        if upload_folder:
            nama_file_gambar = laporan["bukti_watermark_filename"] or laporan["bukti_filename"]
            path_gambar = os.path.join(upload_folder, nama_file_gambar)
            if os.path.exists(path_gambar):
                try:
                    img_reader = ImageReader(path_gambar)
                    iw, ih = img_reader.getSize()
                    max_w = 14 * cm
                    max_h = 18 * cm
                    scale = min(max_w / iw, max_h / ih, 1.0)
                    story.append(RLImage(path_gambar, width=iw * scale, height=ih * scale))
                    story.append(Spacer(1, 6))
                    ditampilkan = True
                except Exception:
                    pass
        if not ditampilkan:
            story.append(Paragraph(
                f"File bukti terlampir: {laporan['bukti_filename']} (format tidak dapat ditampilkan langsung "
                "di dokumen ini, mis. PDF -- buka file asli melalui sistem).", styles["BodyKecil"]
            ))
        if laporan["bukti_hash"]:
            story.append(Paragraph(
                f"<b>Hash Integritas (SHA-256):</b> <font face='Courier' size='8'>{laporan['bukti_hash']}</font>",
                styles["BodyKecil"]
            ))
            story.append(Paragraph(
                "Sidik jari digital file bukti ASLI saat pertama kali diunggah ke sistem. File asli tidak pernah "
                "diubah sejak saat itu -- jika file dihitung ulang hash-nya dan hasilnya berbeda dari nilai di atas, "
                "kemungkinan file telah dimodifikasi. Ini BUKAN bukti keaslian konten sebelum diunggah (mis. "
                "screenshot bisa saja disunting sebelum diunggah), melainkan jaminan bahwa file tidak berubah "
                "SETELAH diterima sistem.", styles["BodyKecil"]
            ))
        story.append(Spacer(1, 10))

    story.append(Paragraph("Proses Verifikasi", styles["H2"]))
    story.append(_kv_table([
        ("Tanggal Verifikasi", laporan["tanggal_verifikasi"]),
        ("Catatan Verifikasi", laporan["catatan_verifikasi"]),
    ]))
    story.append(Spacer(1, 10))

    if laporan["jadwal_mediasi"] or laporan["catatan_mediasi"]:
        story.append(Paragraph("Restorative Justice / Mediasi", styles["H2"]))
        story.append(_kv_table([
            ("Jadwal Mediasi", laporan["jadwal_mediasi"]),
            ("Catatan Hasil Mediasi", laporan["catatan_mediasi"]),
        ]))
        story.append(Spacer(1, 10))

    if laporan["sanksi"] or laporan["tanggal_selesai"]:
        story.append(Paragraph("Keputusan & Penyelesaian", styles["H2"]))
        story.append(_kv_table([
            ("Sanksi / Tindak Lanjut", laporan["sanksi"]),
            ("Tanggal Selesai", laporan["tanggal_selesai"]),
        ]))
        story.append(Spacer(1, 10))

    if notifikasi:
        story.append(Paragraph("Riwayat Notifikasi Orang Tua", styles["H2"]))
        body_style = getSampleStyleSheet()["Normal"]
        data = [["Waktu", "Metode", "Status"]] + [
            [Paragraph(n["waktu_kirim"], body_style), Paragraph(n["metode"], body_style), Paragraph(n["status_kirim"], body_style)]
            for n in notifikasi
        ]
        t = Table(data, colWidths=[3.5 * cm, 7 * cm, 5.5 * cm])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), BIRU_TUA),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#DDDDDD")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ]))
        story.append(t)

    story.append(Spacer(1, 20))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#DDDDDD")))
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        f"Dokumen dicetak otomatis oleh Sistem Whistleblowing Anti-Perundungan pada "
        f"{_tanggal_indonesia()} WIB.", styles["Footer"]
    ))

    doc.build(story, onFirstPage=lambda c, d: _header_footer(c, d, nama_sekolah),
               onLaterPages=lambda c, d: _header_footer(c, d, nama_sekolah))
    buf.seek(0)
    return buf


def buat_pdf_rekap(stats, nama_sekolah):
    """Laporan rekapitulasi bulanan (untuk Kepala Sekolah) -- agregat saja, tanpa data sensitif."""
    buf = io.BytesIO()
    styles = _pdf_styles()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=2 * cm, bottomMargin=2 * cm, leftMargin=2 * cm, rightMargin=2 * cm)
    story = []

    story.append(Paragraph("Laporan Rekapitulasi Penanganan Perundungan", styles["JudulDok"]))
    story.append(Paragraph(f"{nama_sekolah}  |  Periode: {stats['bulan_ini']}", styles["SubJudul"]))
    story.append(Paragraph(
        "Dokumen ini hanya memuat data agregat. Identitas pelapor dan detail kronologi sensitif "
        "tidak termasuk dalam laporan ini demi menjaga kerahasiaan.", styles["Rahasia"]
    ))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#DDDDDD"), spaceAfter=10))

    story.append(Paragraph("Ringkasan", styles["H2"]))
    ringkasan_rows = [("Total Laporan Bulan Ini", stats["total_bulan_ini"]),
                       ("Tingkat Penyelesaian Kasus", f"{stats['tingkat_penyelesaian']}%")]
    for s in stats["per_status"]:
        ringkasan_rows.append((f"Status: {s['status']}", s["c"]))
    story.append(_kv_table(ringkasan_rows))
    story.append(Spacer(1, 14))

    story.append(Paragraph("Tren Laporan 6 Bulan Terakhir", styles["H2"]))
    data = [["Bulan", "Jumlah Laporan"]] + [[b["bulan"], str(b["jumlah"])] for b in stats["bulanan"]]
    t = Table(data, colWidths=[8 * cm, 8 * cm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), BIRU_TUA),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#DDDDDD")),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(t)
    story.append(Spacer(1, 14))

    story.append(Paragraph("5 Kelas dengan Laporan Terbanyak (Sepanjang Waktu)", styles["H2"]))
    if stats["per_kelas"]:
        data2 = [["Kelas", "Jumlah Laporan"]] + [[k["kelas"], str(k["c"])] for k in stats["per_kelas"]]
        t2 = Table(data2, colWidths=[8 * cm, 8 * cm])
        t2.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), TEAL),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#DDDDDD")),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ]))
        story.append(t2)
    else:
        story.append(Paragraph("Belum ada data.", styles["BodyKecil"]))
    story.append(Spacer(1, 14))

    story.append(PageBreak())
    story.append(Paragraph("Titik Rawan Perundungan (Hotspot)", styles["H2"]))
    story.append(Paragraph(
        "Dihitung dari seluruh laporan tervalidasi sepanjang waktu (bukan cuma bulan berjalan) "
        "supaya jumlah datanya lebih stabil secara statistik.", styles["BodyKecil"]
    ))
    if stats.get("sampel_kecil"):
        story.append(Paragraph(
            f"PERINGATAN: total data yang dipakai baru {stats['total_hotspot']} laporan (di bawah ambang "
            f"{stats['hotspot_min_sampel']}). Pola berikut masih indikasi awal, belum cukup kuat untuk "
            f"dasar kebijakan besar (mis. pemasangan CCTV) sendirian.", styles["Rahasia"]
        ))
    if stats.get("hotspot_list"):
        data3 = [["Lokasi", "Jumlah", "Persentase", "Tren Naik?"]] + [
            [h["lokasi"], str(h["jumlah"]), f"{h['persen']}%", "Ya, 2 bulan berturut-turut" if h["tren_naik"] else "-"]
            for h in stats["hotspot_list"]
        ]
        t3 = Table(data3, colWidths=[6 * cm, 2.5 * cm, 3 * cm, 5.5 * cm])
        t3.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), BIRU_TUA),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#DDDDDD")),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ]))
        story.append(t3)
    else:
        story.append(Paragraph("Belum ada data.", styles["BodyKecil"]))

    if stats.get("kombinasi_list"):
        story.append(Spacer(1, 14))
        story.append(Paragraph("Kombinasi Lokasi & Waktu Tersering", styles["H2"]))
        story.append(Paragraph(
            "Kombinasi dengan hanya 1 kasus sengaja tidak ditampilkan, dan angka di bawah "
            f"{stats['hotspot_sel_min_tampil']} disamarkan -- mencegah data yang terlalu spesifik "
            "mengarah ke kasus tertentu.", styles["BodyKecil"]
        ))
        data4 = [["Lokasi", "Kapan", "Jumlah"]] + [
            [k["lokasi"], k["kategori_waktu"], (str(k["jumlah"]) + " kasus") if k["tampilkan_angka"] else "Beberapa (data terbatas)"]
            for k in stats["kombinasi_list"]
        ]
        t4 = Table(data4, colWidths=[6 * cm, 6 * cm, 5 * cm])
        t4.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), TEAL),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#DDDDDD")),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ]))
        story.append(t4)

    story.append(Spacer(1, 20))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#DDDDDD")))
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        f"Dokumen dicetak otomatis oleh Sistem Whistleblowing Anti-Perundungan pada "
        f"{_tanggal_indonesia()} WIB. Cocok dilampirkan untuk rapat dewan guru "
        f"atau dokumen pendukung akreditasi sekolah.", styles["Footer"]
    ))

    doc.build(story, onFirstPage=lambda c, d: _header_footer(c, d, nama_sekolah),
               onLaterPages=lambda c, d: _header_footer(c, d, nama_sekolah))
    buf.seek(0)
    return buf
