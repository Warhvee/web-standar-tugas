"""
Jalankan file ini SEKALI di awal (atau setiap kali ingin reset data demo):
    python init_db.py
"""
import os
import sqlite3
from datetime import datetime
from werkzeug.security import generate_password_hash

from config import Config

DB_PATH = Config.DATABASE
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

if os.path.exists(DB_PATH):
    jawab = input(f"Database sudah ada di {DB_PATH}. Hapus & buat ulang? (y/N): ")
    if jawab.lower() != "y":
        print("Dibatalkan.")
        raise SystemExit
    os.remove(DB_PATH)

conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row

with open(os.path.join(os.path.dirname(__file__), "db.py")) as f:
    pass  # skema diambil langsung dari db.SCHEMA di bawah

from db import SCHEMA
conn.executescript(SCHEMA)

# --- Akun default ---
users = [
    ("bk", generate_password_hash("bk12345"), "Ibu Sri Wahyuni, S.Pd (Guru BK)", "guru_bk"),
    ("kepsek", generate_password_hash("kepsek12345"), "Bapak Ahmad Fauzi, M.Pd (Kepala Sekolah)", "kepsek"),
    ("tu", generate_password_hash("tu12345"), "Ibu Rina Marlina (Staf Tata Usaha)", "tu"),
]
conn.executemany(
    "INSERT INTO users (username, password_hash, nama, role) VALUES (?, ?, ?, ?)",
    users,
)

# --- Daftar kelas contoh ---
kelas_list = [
    "VII-A", "VII-B", "VII-C",
    "VIII-A", "VIII-B", "VIII-C",
    "IX-A", "IX-B", "IX-C",
]
conn.executemany(
    "INSERT INTO kelas (nama_kelas) VALUES (?)",
    [(k,) for k in kelas_list],
)

# --- Artikel edukasi contoh (untuk edukasi berkelanjutan) ---
now = datetime.now().strftime("%Y-%m-%d")
edukasi = [
    (
        "Apa Itu Perundungan (Bullying) dan Jenis-Jenisnya?",
        "Kenali bentuk-bentuk bullying: fisik, verbal, sosial, dan siber -- agar lebih mudah dikenali sejak dini.",
        "Perundungan (bullying) adalah tindakan agresif yang dilakukan secara berulang oleh seseorang atau "
        "sekelompok orang yang memiliki kekuatan lebih terhadap korban yang lebih lemah. Bentuknya bermacam-macam:\n\n"
        "1. Bullying Fisik: memukul, mendorong, merusak barang milik korban.\n"
        "2. Bullying Verbal: mengejek, menghina, memberi julukan buruk, mengancam.\n"
        "3. Bullying Sosial: mengucilkan, menyebar gosip, mempermalukan di depan umum.\n"
        "4. Cyberbullying: menyebar konten memalukan atau ancaman melalui media sosial/chat.\n\n"
        "Semua bentuk ini berdampak serius pada kesehatan mental dan prestasi belajar korban. "
        "Sekolah wajib menyediakan kanal pelaporan yang aman sesuai Permendikbudristek No. 46 Tahun 2023 "
        "tentang Pencegahan dan Penanganan Kekerasan di Lingkungan Satuan Pendidikan.",
        "Tim TPPK Sekolah",
        now,
    ),
    (
        "Konsekuensi Bagi Pelaku Perundungan",
        "Setiap tindakan perundungan yang terbukti akan diproses sesuai SOP sekolah dan dapat berdampak pada catatan disiplin siswa.",
        "Sekolah menerapkan penanganan bertahap terhadap pelaku perundungan yang terbukti melalui investigasi:\n\n"
        "- Pelanggaran ringan: teguran tertulis dan wajib mengikuti sesi edukasi.\n"
        "- Pelanggaran sedang/berulang: pemanggilan orang tua dan sesi restorative justice.\n"
        "- Pelanggaran berat/berulang: skorsing dan pencatatan resmi dalam rekam jejak siswa.\n\n"
        "Tujuan sanksi bukan semata menghukum, melainkan memberi efek jera sekaligus kesempatan pelaku untuk "
        "memperbaiki perilaku melalui pendampingan Guru BK.",
        "Tim TPPK Sekolah",
        now,
    ),
    (
        "Cara Melapor Bullying dengan Aman",
        "Identitas pelapor dijamin dirahasiakan. Laporan diproses oleh Guru BK maksimal 2 hari kerja.",
        "Setiap siswa dapat melaporkan tindakan bullying yang dialami atau disaksikan melalui halaman "
        "'Lapor Sekarang' tanpa perlu mencantumkan identitas. Setelah laporan dikirim, kamu akan menerima "
        "KODE TIKET yang bisa digunakan untuk memeriksa perkembangan laporanmu kapan saja di halaman "
        "'Cek Status Laporan'. Sertakan kronologi kejadian sejelas mungkin dan bukti (jika ada) agar "
        "laporan lebih mudah ditindaklanjuti Guru BK.",
        "Tim TPPK Sekolah",
        now,
    ),
]
conn.executemany(
    "INSERT INTO edukasi (judul, ringkasan, isi, penulis, tanggal_terbit) VALUES (?, ?, ?, ?, ?)",
    edukasi,
)

conn.commit()
conn.close()

print("Database berhasil dibuat di:", DB_PATH)
print("\nAkun login demo:")
print("  Guru BK   -> username: bk      | password: bk12345")
print("  Kepsek    -> username: kepsek  | password: kepsek12345")
print("  Tata Usaha-> username: tu      | password: tu12345")
print("\nSEGERA ganti password ini sebelum dipakai di lingkungan sekolah sungguhan.")
