import os
import io
import random
import string
import hashlib
import smtplib
from email.mime.text import MIMEText
from datetime import datetime, timedelta
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, g, abort, send_file, send_from_directory, jsonify
)
from werkzeug.utils import secure_filename
from werkzeug.security import check_password_hash
from PIL import Image, ImageDraw, ImageFont, ImageOps

from config import Config
from db import get_db, close_db, init_db
from export import buat_excel_laporan, buat_excel_rekap, buat_pdf_kasus, buat_pdf_rekap

app = Flask(__name__)
app.config.from_object(Config)
app.teardown_appcontext(close_db)


# ---------------------------------------------------------------------------
# CLI: `flask init-db` sebagai alternatif dari python init_db.py
# ---------------------------------------------------------------------------
@app.cli.command("init-db")
def init_db_command():
    init_db()
    print("Database diinisialisasi.")


# ---------------------------------------------------------------------------
# Helper umum
# ---------------------------------------------------------------------------
def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def buat_kode_tiket():
    tahun = datetime.now().strftime("%y")
    acak = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"LP-{tahun}-{acak}"


def hash_ip(ip):
    # IP tidak disimpan mentah -- hanya hash-nya, cukup untuk deteksi spam
    # tanpa menyimpan data pribadi secara langsung.
    return hashlib.sha256((ip + app.config["SECRET_KEY"]).encode()).hexdigest()


def allowed_file(filename):
    return "." in filename and \
        filename.rsplit(".", 1)[1].lower() in app.config["ALLOWED_EXTENSIONS"]


# ---------------------------------------------------------------------------
# Digital Evidence Vault: hash integritas + watermark waktu untuk bukti unggahan
# ---------------------------------------------------------------------------
FONT_BOLD_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "fonts", "DejaVuSans-Bold.ttf")


def hitung_hash_file(filepath):
    """SHA-256 dari isi file ASLI, dihitung tepat setelah diunggah -- sebelum
    diubah apa pun. File asli TIDAK PERNAH dimodifikasi setelah ini supaya
    hash-nya tetap valid selamanya (prinsip integritas bukti digital)."""
    sha256 = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


def hitung_hash_bytes(data):
    """Sama seperti hitung_hash_file(), tapi langsung dari bytes di memori --
    dipakai saat bukti dinormalisasi/dikompres SEBELUM ditulis ke disk sama
    sekali, supaya versi yang di-hash persis sama dengan versi yang tersimpan."""
    return hashlib.sha256(data).hexdigest()


def normalisasi_gambar_bukti(file_storage, max_dim, kualitas_jpeg):
    """Baca gambar bukti langsung dari upload (belum pernah disimpan ke disk),
    perbaiki orientasi (banyak foto kamera HP tersimpan 'miring' dan hanya
    diputar lewat metadata EXIF), perkecil resolusi kalau melebihi batas, lalu
    kembalikan bytes JPEG terkompresi.

    KEPUTUSAN ARSITEKTUR PENTING (didokumentasikan juga di README): hasil dari
    fungsi inilah yang dianggap sebagai "bukti asli resmi" sejak masuk sistem --
    hash SHA-256 dihitung dari bytes hasil kompresi ini, BUKAN dari file mentah
    yang diunggah. Setelah titik ini, file tidak akan pernah diubah lagi. Ini
    bukan mengorbankan integritas forensik, melainkan menetapkan dengan sadar
    kapan "versi resmi" mulai berlaku -- demi mengelola kapasitas server yang
    terbatas tanpa membebani siswa untuk mengompres foto secara manual.
    """
    img = Image.open(file_storage.stream)
    img = ImageOps.exif_transpose(img)  # perbaiki foto yang terbalik/miring dari kamera HP
    img = img.convert("RGB")

    w, h = img.size
    if max(w, h) > max_dim:
        skala = max_dim / max(w, h)
        img = img.resize((max(int(w * skala), 1), max(int(h * skala), 1)), Image.LANCZOS)

    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=kualitas_jpeg, optimize=True)
    return buf.getvalue()


def hitung_ukuran_folder_bukti():
    """Total ukuran semua file di secure_uploads/ (dalam MB) -- untuk indikator
    peringatan dini kapasitas penyimpanan di dashboard Guru BK."""
    total_bytes = 0
    folder = Config.UPLOAD_FOLDER
    if os.path.isdir(folder):
        for nama_file in os.listdir(folder):
            path = os.path.join(folder, nama_file)
            if os.path.isfile(path):
                total_bytes += os.path.getsize(path)
    return round(total_bytes / (1024 * 1024), 1)


def buat_watermark_bukti(filepath_asli, filepath_watermark, kode_tiket, waktu_str, nama_sekolah):
    """Buat SALINAN TERPISAH dari bukti (khusus untuk ditampilkan/dicetak PDF)
    dengan stempel waktu unggah -- file ASLI di filepath_asli tidak disentuh.
    Hanya untuk file gambar (JPG/PNG); PDF evidence tidak di-watermark visual,
    integritasnya tetap dijaga lewat hash saja.
    """
    try:
        img = Image.open(filepath_asli).convert("RGB")
    except Exception:
        return False  # bukan file gambar yang bisa dibuka PIL (mis. PDF) -- tidak apa, hash tetap ada

    w, h = img.size
    baris1 = f"Diunggah ke sistem: {waktu_str} WIB"
    baris2 = f"Kode Tiket: {kode_tiket}  |  {nama_sekolah}"

    ukuran_font = max(int(w * 0.028), 12)
    font = None
    # Kecilkan font bertahap sampai kedua baris muat di lebar gambar (penting utk
    # screenshot chat yang biasanya sempit/portrait)
    while ukuran_font >= 10:
        try:
            font_coba = ImageFont.truetype(FONT_BOLD_PATH, ukuran_font)
        except Exception:
            font_coba = ImageFont.load_default()
            font = font_coba
            break
        tmp_draw = ImageDraw.Draw(img)
        lebar1 = tmp_draw.textlength(baris1, font=font_coba)
        lebar2 = tmp_draw.textlength(baris2, font=font_coba)
        if max(lebar1, lebar2) <= w - 20:
            font = font_coba
            break
        ukuran_font -= 2
    if font is None:
        font = ImageFont.truetype(FONT_BOLD_PATH, 10) if os.path.exists(FONT_BOLD_PATH) else ImageFont.load_default()

    draw = ImageDraw.Draw(img)
    bbox = draw.textbbox((0, 0), baris1, font=font)
    tinggi_baris = (bbox[3] - bbox[1]) + 4
    pad = int(ukuran_font * 0.5)
    bar_h = tinggi_baris * 2 + pad * 2

    # Bar semi-transparan di bagian bawah gambar -- konten bukti asli tetap terlihat
    # samar di baliknya, tidak menutupi total (crop -> blend -> tempel kembali).
    img_rgba = img.convert("RGBA")
    region = img_rgba.crop((0, h - bar_h, w, h))
    overlay = Image.new("RGBA", (w, bar_h), (18, 50, 92, 195))
    blended = Image.alpha_composite(region, overlay)
    img_rgba.paste(blended, (0, h - bar_h))
    img = img_rgba.convert("RGB")

    draw = ImageDraw.Draw(img)
    draw.text((pad, h - bar_h + pad), baris1, font=font, fill=(255, 255, 255))
    draw.text((pad, h - bar_h + pad + tinggi_baris), baris2, font=font, fill=(255, 255, 255))

    img.save(filepath_watermark, quality=90)
    return True


def cek_rate_limit(ip_hash):
    """True jika MASIH boleh mengirim laporan, False jika sudah kena limit."""
    db = get_db()
    batas_waktu = (datetime.now() - timedelta(minutes=app.config["RATE_LIMIT_MENIT"])).strftime("%Y-%m-%d %H:%M:%S")
    jumlah = db.execute(
        "SELECT COUNT(*) AS c FROM rate_limit_log WHERE ip_hash = ? AND waktu > ?",
        (ip_hash, batas_waktu),
    ).fetchone()["c"]
    return jumlah < app.config["RATE_LIMIT_MAKS"]


def catat_rate_limit(ip_hash):
    db = get_db()
    db.execute("INSERT INTO rate_limit_log (ip_hash, waktu) VALUES (?, ?)", (ip_hash, now_str()))
    db.commit()


def hitung_riwayat_pelaku(nama, kelas):
    """Jumlah laporan yang sudah TERBUKTI valid (bukan Ditolak) atas nama+kelas yang sama."""
    db = get_db()
    row = db.execute(
        """SELECT COUNT(*) AS c FROM laporan
           WHERE nama_terduga_pelaku = ? AND kelas_terduga_pelaku = ?
           AND status != 'Ditolak'""",
        (nama, kelas),
    ).fetchone()
    return row["c"]


def saran_sanksi(jumlah_riwayat):
    """Matriks sanksi bertingkat -- BK tetap bisa override secara manual."""
    if jumlah_riwayat <= 1:
        return "Ringan", "Teguran tertulis + wajib mengikuti sesi edukasi anti-bullying."
    elif jumlah_riwayat == 2:
        return "Sedang", "Pemanggilan orang tua + sesi Restorative Justice wajib."
    else:
        return "Berat", "Skorsing sesuai tata tertib sekolah + eskalasi ke Kepala Sekolah/TPPK."


def kirim_email_smtp(pesan, tujuan_email="email_orangtua@contoh.sch.id"):
    """Kirim email sungguhan lewat SMTP (mis. Gmail App Password)."""
    msg = MIMEText(pesan)
    msg["Subject"] = f"[{app.config['NAMA_SEKOLAH']}] Panggilan Terkait Laporan Kedisiplinan"
    msg["From"] = app.config["SMTP_USER"]
    msg["To"] = tujuan_email
    with smtplib.SMTP(app.config["SMTP_HOST"], app.config["SMTP_PORT"]) as server:
        server.starttls()
        server.login(app.config["SMTP_USER"], app.config["SMTP_PASSWORD"])
        server.send_message(msg)


def kirim_wa_fonnte(nomor_wa, pesan):
    """
    Contoh integrasi kirim WhatsApp sungguhan via Fonnte (https://fonnte.com).
    Fonnte punya paket gratis untuk uji coba/skala kecil -- cocok untuk kelanjutan PKM ini.

    Cara pakai:
      1. Daftar di fonnte.com, hubungkan nomor WA sekolah lewat scan QR.
      2. Salin token dari dashboard, isi di config.py -> FONNTE_TOKEN.
      3. Set config.py -> MODE_NOTIFIKASI = "whatsapp_fonnte".
      4. Saat mengirim notifikasi di dashboard BK, isi nomor WA orang tua pada kolom yang tersedia.
    """
    import requests  # import lokal supaya app tetap jalan meski 'requests' belum ter-install saat mode simulasi

    response = requests.post(
        "https://api.fonnte.com/send",
        headers={"Authorization": app.config["FONNTE_TOKEN"]},
        data={"target": nomor_wa, "message": pesan},
        timeout=15,
    )
    data = response.json()
    if not data.get("status", False) and not data.get("detail"):
        raise RuntimeError(f"Fonnte menolak permintaan: {data}")
    return data


def kirim_notifikasi_ortu(laporan_id, pesan, nomor_wa=None):
    """Kirim (atau simulasikan) notifikasi ke orang tua pelaku sesuai MODE_NOTIFIKASI aktif."""
    db = get_db()
    mode = app.config["MODE_NOTIFIKASI"]

    if mode == "email_smtp" and app.config["SMTP_HOST"]:
        metode = "Email (SMTP)"
        try:
            kirim_email_smtp(pesan)
            status_kirim = "Terkirim"
        except Exception as e:
            status_kirim = f"Gagal: {e}"

    elif mode == "whatsapp_fonnte" and app.config["FONNTE_TOKEN"]:
        metode = "WhatsApp (Fonnte)"
        if not nomor_wa:
            status_kirim = "Gagal: nomor WhatsApp orang tua belum diisi"
        else:
            try:
                kirim_wa_fonnte(nomor_wa, pesan)
                status_kirim = "Terkirim"
            except Exception as e:
                status_kirim = f"Gagal: {e}"

    else:
        # Mode simulasi -- default, aman untuk demo, tidak butuh kredensial apapun
        metode = "Simulasi (belum terhubung ke email/WA sungguhan)"
        status_kirim = "Tercatat (simulasi)"

    db.execute(
        "INSERT INTO notifikasi_ortu (laporan_id, pesan, metode, status_kirim, waktu_kirim) VALUES (?,?,?,?,?)",
        (laporan_id, pesan, metode, status_kirim, now_str()),
    )
    db.commit()
    return status_kirim


def catat_log(aksi, laporan_id=None):
    db = get_db()
    user_id = session.get("user_id")
    db.execute(
        "INSERT INTO log_akses (user_id, laporan_id, aksi, waktu) VALUES (?,?,?,?)",
        (user_id, laporan_id, aksi, now_str()),
    )
    db.commit()


def cek_status_skbb(nama, kelas):
    """Cek Gerbang Persetujuan SKBB untuk seorang siswa berdasarkan nama+kelas.

    PRINSIP PENTING: fungsi ini TIDAK PERNAH membedakan antara 'tidak pernah ada
    catatan' dan 'pernah ada catatan tapi sudah direhabilitasi/disetujui' pada
    hasil yang ditampilkan ke TU -- keduanya sama-sama tampil 'aman'. Ini sengaja,
    supaya proses rehabilitasi benar-benar bersih dan tidak diam-diam tetap
    'menandai' siswa tsb di mata staf yang mengecek di kemudian hari.
    """
    db = get_db()
    rows = db.execute(
        """SELECT * FROM status_skbb
           WHERE lower(trim(nama_siswa)) = lower(trim(?)) AND lower(trim(kelas_siswa)) = lower(trim(?))
           ORDER BY dibuat_pada DESC""",
        (nama, kelas),
    ).fetchall()
    aktif_menghambat = [r for r in rows if r["status"] in ("Menunggu Persetujuan", "Ditolak")]
    return {"diblokir": len(aktif_menghambat) > 0, "jumlah_flag_aktif": len(aktif_menghambat)}


# ---------------------------------------------------------------------------
# Auth decorators
# ---------------------------------------------------------------------------
def login_required(role=None):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            if "user_id" not in session:
                flash("Silakan login terlebih dahulu.", "warning")
                return redirect(url_for("login", next=request.path))
            if role and session.get("role") != role:
                abort(403)
            return f(*args, **kwargs)
        return wrapped
    return decorator


@app.context_processor
def inject_globals():
    return {
        "nama_sekolah": app.config["NAMA_SEKOLAH"],
        "current_year": datetime.now().year,
        "pwa_short_name": app.config["PWA_SHORT_NAME"],
    }


# ---------------------------------------------------------------------------
# PWA: manifest.json & service-worker.js
# ---------------------------------------------------------------------------
@app.route("/manifest.json")
def pwa_manifest():
    """Dibuat dinamis (bukan file statis) supaya nama & ikon PWA otomatis ikut
    konfigurasi sekolah di config.py, tanpa perlu edit file JSON manual."""
    data = {
        "name": app.config["PWA_APP_NAME"],
        "short_name": app.config["PWA_SHORT_NAME"],
        "description": app.config["PWA_DESCRIPTION"],
        "start_url": "/",
        "scope": "/",
        "display": "standalone",
        "background_color": "#12325c",
        "theme_color": "#12325c",
        "orientation": "portrait",
        "icons": [
            {"src": url_for("static", filename="icons/icon-192.png"), "sizes": "192x192", "type": "image/png", "purpose": "any"},
            {"src": url_for("static", filename="icons/icon-512.png"), "sizes": "512x512", "type": "image/png", "purpose": "any"},
            {"src": url_for("static", filename="icons/icon-maskable-512.png"), "sizes": "512x512", "type": "image/png", "purpose": "maskable"},
        ],
    }
    resp = jsonify(data)
    resp.headers["Content-Type"] = "application/manifest+json"
    return resp


@app.route("/service-worker.js")
def pwa_service_worker():
    """Wajib dilayani dari ROOT (bukan /static/service-worker.js) beserta header
    Service-Worker-Allowed, supaya scope-nya mencakup seluruh situs -- bukan cuma /static/."""
    resp = send_from_directory(app.static_folder, "service-worker.js", mimetype="application/javascript")
    resp.headers["Service-Worker-Allowed"] = "/"
    resp.headers["Cache-Control"] = "no-cache"  # supaya update service worker langsung terdeteksi browser
    return resp


@app.route("/offline.html")
def pwa_offline():
    return send_from_directory(app.static_folder, "offline.html")


# ---------------------------------------------------------------------------
# HALAMAN PUBLIK (tanpa login)
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    db = get_db()
    artikel_terbaru = db.execute(
        "SELECT * FROM edukasi ORDER BY tanggal_terbit DESC LIMIT 3"
    ).fetchall()

    bulan_ini = datetime.now().strftime("%Y-%m")
    kelas_list = db.execute("SELECT nama_kelas FROM kelas ORDER BY nama_kelas").fetchall()
    kelas_bersih = []
    for k in kelas_list:
        ada_laporan = db.execute(
            """SELECT COUNT(*) AS c FROM laporan
               WHERE kelas_terduga_pelaku = ? AND status != 'Ditolak'
               AND strftime('%Y-%m', tanggal_masuk) = ?""",
            (k["nama_kelas"], bulan_ini),
        ).fetchone()["c"]
        if ada_laporan == 0:
            kelas_bersih.append(k["nama_kelas"])

    return render_template(
        "index.html",
        artikel_terbaru=artikel_terbaru,
        kelas_bersih=kelas_bersih[:6],
        total_kelas_bersih=len(kelas_bersih),
        total_kelas=len(kelas_list),
    )


@app.route("/lapor", methods=["GET", "POST"])
def lapor():
    db = get_db()

    if "captcha_a" not in session:
        session["captcha_a"] = random.randint(1, 10)
        session["captcha_b"] = random.randint(1, 10)

    if request.method == "POST":
        ip = request.headers.get("X-Forwarded-For", request.remote_addr) or "unknown"
        ip_h = hash_ip(ip)

        # 1) Cek rate limit dulu sebelum proses apapun
        if not cek_rate_limit(ip_h):
            flash(
                f"Terlalu banyak laporan dikirim dari jaringan ini dalam {app.config['RATE_LIMIT_MENIT']} menit terakhir. "
                "Silakan coba lagi nanti. Ini untuk menjaga kredibilitas laporan yang masuk.",
                "danger",
            )
            return redirect(url_for("lapor"))

        # 2) Verifikasi captcha matematika sederhana (anti-bot, tanpa API berbayar)
        try:
            jawaban = int(request.form.get("captcha", -999))
        except ValueError:
            jawaban = -999
        if jawaban != session.get("captcha_a", -1) + session.get("captcha_b", -1):
            flash("Jawaban verifikasi salah, silakan coba lagi.", "danger")
            session.pop("captcha_a", None)
            session.pop("captcha_b", None)
            return redirect(url_for("lapor"))

        kronologi = request.form.get("kronologi", "").strip()
        nama_pelaku = request.form.get("nama_terduga_pelaku", "").strip()
        kelas_pelaku = request.form.get("kelas_terduga_pelaku", "").strip()
        waktu_kejadian = request.form.get("waktu_kejadian", "").strip()
        kategori_waktu = request.form.get("kategori_waktu", "").strip()
        lokasi_kejadian = request.form.get("lokasi_kejadian", "").strip()
        lokasi_lainnya_detail = request.form.get("lokasi_lainnya_detail", "").strip()
        jenis = request.form.get("jenis_kekerasan", "").strip()
        darurat = 1 if request.form.get("darurat") == "on" else 0

        # 3) Validasi
        jumlah_kata = len(kronologi.split())
        errors = []
        if jumlah_kata < app.config["MIN_KATA_KRONOLOGI"]:
            errors.append(
                f"Kronologi kejadian minimal {app.config['MIN_KATA_KRONOLOGI']} kata "
                f"(saat ini {jumlah_kata} kata). Jelaskan sedetail mungkin agar mudah ditindaklanjuti."
            )
        if not nama_pelaku or not kelas_pelaku:
            errors.append("Nama dan kelas terduga pelaku wajib diisi.")
        if not waktu_kejadian:
            errors.append("Waktu kejadian wajib diisi.")
        if kategori_waktu not in app.config["KATEGORI_WAKTU_OPSI"]:
            errors.append("Kategori waktu tidak valid, silakan pilih dari daftar yang tersedia.")
        if lokasi_kejadian not in app.config["LOKASI_KEJADIAN_OPSI"]:
            errors.append("Lokasi kejadian tidak valid, silakan pilih dari daftar yang tersedia.")
        if lokasi_kejadian == "Lainnya" and not lokasi_lainnya_detail:
            errors.append("Mohon sebutkan lokasi kejadian pada kolom yang tersedia.")

        if errors:
            for e in errors:
                flash(e, "danger")
            session["captcha_a"] = random.randint(1, 10)
            session["captcha_b"] = random.randint(1, 10)
            return redirect(url_for("lapor"))

        # 4) Simpan bukti (opsional) -- + hash integritas, kompresi otomatis, & watermark
        #    (Digital Evidence Vault). PRINSIP UTAMA: kegagalan di langkah ini TIDAK BOLEH
        #    menggagalkan laporan secara keseluruhan -- teks kronologi jauh lebih penting
        #    daripada lampiran foto, dan siswa yang sudah memberanikan diri melapor tidak
        #    boleh menanggung akibat masalah infrastruktur server (mis. disk penuh).
        kode_tiket = buat_kode_tiket()
        bukti_filename = None
        bukti_hash = None
        bukti_watermark_filename = None
        bukti_upload_gagal = 0
        file = request.files.get("bukti")
        if file and file.filename:
            if allowed_file(file.filename):
                ext = file.filename.rsplit(".", 1)[1].lower()
                path_asli = None
                try:
                    if ext in ("jpg", "jpeg", "png"):
                        # Kompres & perkecil resolusi DULU, baru hitung hash dari hasilnya --
                        # supaya file yang tersimpan sejak awal sudah versi final yang tidak
                        # akan diubah lagi (lihat penjelasan lengkap di normalisasi_gambar_bukti()).
                        data_final = normalisasi_gambar_bukti(
                            file, app.config["MAX_DIMENSI_GAMBAR_PX"], app.config["KUALITAS_JPEG_BUKTI"]
                        )
                        ext_simpan = "jpg"  # selalu disimpan sbg JPEG setelah dinormalisasi
                    else:
                        data_final = file.read()
                        ext_simpan = ext  # PDF tidak dikompres -- disimpan apa adanya

                    bukti_hash = hitung_hash_bytes(data_final)
                    bukti_filename = f"{kode_tiket}.{ext_simpan}"
                    path_asli = os.path.join(app.config["UPLOAD_FOLDER"], bukti_filename)
                    with open(path_asli, "wb") as f:
                        f.write(data_final)

                    if ext_simpan in ("jpg", "jpeg", "png"):
                        nama_watermark = f"{kode_tiket}_watermark.jpg"
                        path_watermark = os.path.join(app.config["UPLOAD_FOLDER"], nama_watermark)
                        try:
                            if buat_watermark_bukti(
                                path_asli, path_watermark, kode_tiket, now_str(), app.config["NAMA_SEKOLAH"]
                            ):
                                bukti_watermark_filename = nama_watermark
                        except Exception:
                            pass  # watermark gagal -> tidak fatal, tampilan otomatis jatuh ke file asli

                except Exception:
                    # Kemungkinan besar disk penuh, atau file gambar korup/tidak valid.
                    # Bersihkan sisa file parsial (kalau sempat tertulis sebagian), lalu
                    # tandai gagal -- tapi laporan TETAP lanjut disimpan di bawah.
                    bukti_filename = None
                    bukti_hash = None
                    bukti_watermark_filename = None
                    bukti_upload_gagal = 1
                    if path_asli and os.path.exists(path_asli):
                        try:
                            os.remove(path_asli)
                        except OSError:
                            pass
            else:
                flash("Format bukti tidak didukung. Gunakan JPG, PNG, atau PDF.", "danger")
                return redirect(url_for("lapor"))

        db.execute(
            """INSERT INTO laporan
               (kode_tiket, waktu_kejadian, kategori_waktu, lokasi_kejadian, lokasi_lainnya_detail,
                jenis_kekerasan, kronologi, nama_terduga_pelaku, kelas_terduga_pelaku, bukti_filename,
                bukti_hash, bukti_watermark_filename, bukti_upload_gagal, darurat, status, ip_hash, tanggal_masuk)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (kode_tiket, waktu_kejadian, kategori_waktu, lokasi_kejadian, lokasi_lainnya_detail or None,
             jenis, kronologi, nama_pelaku, kelas_pelaku, bukti_filename,
             bukti_hash, bukti_watermark_filename, bukti_upload_gagal, darurat, "Menunggu Verifikasi", ip_h, now_str()),
        )
        db.commit()
        catat_rate_limit(ip_h)
        session.pop("captcha_a", None)
        session.pop("captcha_b", None)

        return redirect(url_for("lapor_berhasil", kode=kode_tiket))

    return render_template(
        "lapor.html",
        lokasi_kejadian_opsi=app.config["LOKASI_KEJADIAN_OPSI"],
        kategori_waktu_opsi=app.config["KATEGORI_WAKTU_OPSI"],
    )


@app.route("/lapor/berhasil")
def lapor_berhasil():
    kode = request.args.get("kode", "")
    bukti_gagal = False
    if kode:
        db = get_db()
        row = db.execute(
            "SELECT bukti_upload_gagal FROM laporan WHERE kode_tiket = ?", (kode,)
        ).fetchone()
        if row:
            bukti_gagal = bool(row["bukti_upload_gagal"])
    return render_template("lapor_berhasil.html", kode=kode, bukti_gagal=bukti_gagal)


@app.route("/cek-status", methods=["GET", "POST"])
def cek_status():
    laporan = None
    dicari = False
    if request.method == "POST":
        dicari = True
        kode = request.form.get("kode_tiket", "").strip().upper()
        db = get_db()
        laporan = db.execute(
            "SELECT status, tanggal_masuk, tanggal_verifikasi, tanggal_selesai, sanksi "
            "FROM laporan WHERE kode_tiket = ?",
            (kode,),
        ).fetchone()
    return render_template("cek_status.html", laporan=laporan, dicari=dicari)


@app.route("/edukasi")
def edukasi_list():
    db = get_db()
    artikel = db.execute("SELECT * FROM edukasi ORDER BY tanggal_terbit DESC").fetchall()
    return render_template("edukasi_list.html", artikel=artikel)


@app.route("/edukasi/<int:artikel_id>")
def edukasi_detail(artikel_id):
    db = get_db()
    artikel = db.execute("SELECT * FROM edukasi WHERE id = ?", (artikel_id,)).fetchone()
    if not artikel:
        abort(404)
    return render_template("edukasi_detail.html", artikel=artikel)


@app.route("/papan-kehormatan")
def papan_kehormatan():
    """Halaman publik -- SENGAJA tidak menampilkan peringkat maupun jumlah laporan
    per kelas. Leaderboard kompetitif untuk isu sensitif begini berisiko nyata:
    bisa memicu tekanan sosial antar-siswa untuk menyembunyikan laporan supaya
    kelasnya 'tidak kalah', dan bisa menstigma korban/teman sekelasnya kalau
    kelas mereka 'turun peringkat'. Yang ditampilkan cuma pengakuan POSITIF
    untuk kelas yang bersih -- tanpa urutan, tanpa angka, semua diperlakukan
    setara. Data lengkap (jumlah, tren) tetap ada, tapi HANYA di dashboard
    Kepala Sekolah yang sudah wajib login (lihat hitung_rekap_kepsek())."""
    db = get_db()
    bulan_ini = datetime.now().strftime("%Y-%m")
    kelas_list = db.execute("SELECT nama_kelas FROM kelas ORDER BY nama_kelas").fetchall()
    kelas_bersih = []
    for k in kelas_list:
        jumlah = db.execute(
            """SELECT COUNT(*) AS c FROM laporan
               WHERE kelas_terduga_pelaku = ? AND status != 'Ditolak'
               AND strftime('%Y-%m', tanggal_masuk) = ?""",
            (k["nama_kelas"], bulan_ini),
        ).fetchone()["c"]
        if jumlah == 0:
            kelas_bersih.append(k["nama_kelas"])
    return render_template(
        "papan_kehormatan.html", kelas_bersih=kelas_bersih,
        total_kelas=len(kelas_list), bulan_ini=bulan_ini,
    )


# ---------------------------------------------------------------------------
# AUTH
# ---------------------------------------------------------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["nama"] = user["nama"]
            session["role"] = user["role"]
            flash(f"Selamat datang, {user['nama']}.", "success")
            tujuan = {"guru_bk": "bk_dashboard", "kepsek": "kepsek_dashboard", "tu": "tu_dashboard"}.get(user["role"], "index")
            return redirect(url_for(tujuan))
        flash("Username atau password salah.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Kamu telah logout.", "info")
    return redirect(url_for("index"))


# ---------------------------------------------------------------------------
# AREA GURU BK (TPPK) -- wajib login
# ---------------------------------------------------------------------------
@app.route("/bk/dashboard")
@login_required(role="guru_bk")
def bk_dashboard():
    db = get_db()
    status_filter = request.args.get("status", "")
    query = "SELECT * FROM laporan"
    params = []
    if status_filter:
        query += " WHERE status = ?"
        params.append(status_filter)
    query += " ORDER BY darurat DESC, tanggal_masuk DESC"
    laporan_semua = db.execute(query, params).fetchall()

    ringkasan = {
        "Menunggu Verifikasi": 0, "Diproses": 0, "Mediasi": 0, "Selesai": 0, "Ditolak": 0
    }
    for row in db.execute("SELECT status, COUNT(*) as c FROM laporan GROUP BY status"):
        ringkasan[row["status"]] = row["c"]

    ukuran_storage_mb = hitung_ukuran_folder_bukti()

    return render_template(
        "bk_dashboard.html", laporan_semua=laporan_semua,
        ringkasan=ringkasan, status_filter=status_filter,
        sla_verifikasi=app.config["SLA_VERIFIKASI_HARI"],
        sla_keputusan=app.config["SLA_KEPUTUSAN_HARI"],
        ukuran_storage_mb=ukuran_storage_mb,
        storage_warning_mb=app.config["STORAGE_WARNING_MB"],
    )


@app.route("/bk/laporan/export.xlsx")
@login_required(role="guru_bk")
def bk_export_excel():
    db = get_db()
    status_filter = request.args.get("status", "")
    query = "SELECT * FROM laporan"
    params = []
    if status_filter:
        query += " WHERE status = ?"
        params.append(status_filter)
    query += " ORDER BY tanggal_masuk DESC"
    rows = db.execute(query, params).fetchall()
    buf = buat_excel_laporan(rows, app.config["NAMA_SEKOLAH"])
    catat_log("Mengekspor rekap laporan ke Excel")
    nama_file = f"rekap-laporan-{datetime.now().strftime('%Y%m%d')}.xlsx"
    return send_file(buf, as_attachment=True, download_name=nama_file,
                      mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/bk/laporan/<int:laporan_id>/export.pdf")
@login_required(role="guru_bk")
def bk_export_kasus_pdf(laporan_id):
    db = get_db()
    laporan = db.execute("SELECT * FROM laporan WHERE id = ?", (laporan_id,)).fetchone()
    if not laporan:
        abort(404)
    notifikasi = db.execute(
        "SELECT * FROM notifikasi_ortu WHERE laporan_id=? ORDER BY waktu_kirim", (laporan_id,)
    ).fetchall()
    buf = buat_pdf_kasus(laporan, notifikasi, app.config["NAMA_SEKOLAH"], upload_folder=app.config["UPLOAD_FOLDER"])
    catat_log("Mengunduh dokumentasi kasus (PDF)", laporan_id)
    nama_file = f"dokumentasi-{laporan['kode_tiket']}.pdf"
    return send_file(buf, as_attachment=True, download_name=nama_file, mimetype="application/pdf")


@app.route("/bk/bukti/<path:filename>")
@login_required(role="guru_bk")
def bk_bukti_file(filename):
    """Satu-satunya jalur resmi untuk membuka file bukti (asli maupun watermark).

    Bukti TIDAK disajikan lewat /static/ -- kalau lewat situ, siapa pun yang
    tahu/menebak URL-nya bisa membukanya tanpa login sama sekali. Lewat sini,
    wajib login sebagai Guru BK dulu. send_from_directory juga otomatis
    menolak upaya path traversal (mis. "../../app.py") di parameter filename.
    """
    catat_log(f"Membuka file bukti: {filename}")
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)


@app.route("/bk/laporan/<int:laporan_id>", methods=["GET", "POST"])
@login_required(role="guru_bk")
def bk_laporan_detail(laporan_id):
    db = get_db()
    laporan = db.execute("SELECT * FROM laporan WHERE id = ?", (laporan_id,)).fetchone()
    if not laporan:
        abort(404)

    catat_log("Membuka detail laporan", laporan_id)

    if request.method == "POST":
        aksi = request.form.get("aksi")

        if aksi == "verifikasi":
            keputusan = request.form.get("keputusan_verifikasi")  # 'valid' atau 'tolak'
            catatan = request.form.get("catatan_verifikasi", "").strip()
            nis = request.form.get("nis_terduga_pelaku", "").strip()
            if keputusan == "valid":
                db.execute(
                    """UPDATE laporan SET status='Diproses', catatan_verifikasi=?, tanggal_verifikasi=?,
                       nis_terduga_pelaku=? WHERE id=?""",
                    (catatan, now_str(), nis or None, laporan_id),
                )
                db.commit()
                catat_log("Memverifikasi laporan sebagai VALID", laporan_id)
                flash("Laporan diverifikasi valid dan berstatus Diproses.", "success")
            else:
                db.execute(
                    "UPDATE laporan SET status='Ditolak', catatan_verifikasi=?, tanggal_verifikasi=? WHERE id=?",
                    (catatan, now_str(), laporan_id),
                )
                db.commit()
                catat_log("Menolak laporan (tidak cukup bukti / tidak valid)", laporan_id)
                flash("Laporan ditandai tidak valid/ditolak.", "info")

        elif aksi == "kirim_notifikasi":
            pesan = request.form.get("pesan_notifikasi", "").strip()
            nomor_wa = request.form.get("nomor_wa_ortu", "").strip() or None
            status_kirim = kirim_notifikasi_ortu(laporan_id, pesan, nomor_wa=nomor_wa)
            catat_log(f"Mengirim notifikasi ke orang tua ({status_kirim})", laporan_id)
            flash(f"Notifikasi ke orang tua: {status_kirim}.", "success")

        elif aksi == "jadwal_mediasi":
            jadwal = request.form.get("jadwal_mediasi", "").strip()
            db.execute(
                "UPDATE laporan SET status='Mediasi', jadwal_mediasi=? WHERE id=?",
                (jadwal, laporan_id),
            )
            db.commit()
            catat_log("Menjadwalkan sesi Restorative Justice", laporan_id)
            flash("Sesi mediasi/Restorative Justice dijadwalkan.", "success")

        elif aksi == "selesaikan":
            catatan_mediasi = request.form.get("catatan_mediasi", "").strip()
            sanksi = request.form.get("sanksi", "").strip()
            tingkat_pelanggaran = request.form.get("tingkat_pelanggaran", "").strip()

            if tingkat_pelanggaran not in app.config["TINGKAT_PELANGGARAN_OPSI"]:
                flash("Tingkat pelanggaran wajib dipilih sebelum kasus bisa diselesaikan.", "danger")
                return redirect(url_for("bk_laporan_detail", laporan_id=laporan_id))

            db.execute(
                """UPDATE laporan SET status='Selesai', catatan_mediasi=?, sanksi=?, tingkat_pelanggaran=?,
                   tanggal_selesai=? WHERE id=?""",
                (catatan_mediasi, sanksi, tingkat_pelanggaran, now_str(), laporan_id),
            )
            db.commit()
            catat_log(f"Menyelesaikan & mengarsipkan kasus (tingkat: {tingkat_pelanggaran})", laporan_id)
            flash("Kasus ditandai selesai dan diarsipkan sebagai rekam jejak.", "success")

            # --- Gerbang Persetujuan SKBB: HANYA dipicu untuk tingkat 'Berat' ---
            # Ini BUKAN pemblokiran otomatis final -- hanya membuat flag yang nanti
            # butuh keputusan eksplisit dari Kepala Sekolah (lihat cek_status_skbb()).
            if tingkat_pelanggaran == app.config["TINGKAT_PEMICU_SKBB"]:
                sudah_ada = db.execute(
                    "SELECT id FROM status_skbb WHERE laporan_id=?", (laporan_id,)
                ).fetchone()
                if not sudah_ada:
                    db.execute(
                        """INSERT INTO status_skbb
                           (laporan_id, nama_siswa, kelas_siswa, nis_siswa, status, dibuat_pada)
                           VALUES (?,?,?,?,?,?)""",
                        (laporan_id, laporan["nama_terduga_pelaku"], laporan["kelas_terduga_pelaku"],
                         laporan["nis_terduga_pelaku"], "Menunggu Persetujuan", now_str()),
                    )
                    db.commit()
                    catat_log(
                        "Kasus BERAT -- status SKBB siswa kini butuh persetujuan Kepala Sekolah",
                        laporan_id,
                    )
                    flash(
                        "Karena tingkat pelanggaran BERAT, penerbitan SKBB siswa ini sekarang butuh "
                        "persetujuan eksplisit dari Kepala Sekolah (lihat status di bawah).",
                        "warning",
                    )

        elif aksi == "rehabilitasi":
            catatan_rehab = request.form.get("catatan_rehabilitasi", "").strip()
            if not catatan_rehab:
                flash("Alasan rehabilitasi wajib diisi (mis. bukti sesi konseling/perbaikan perilaku).", "danger")
                return redirect(url_for("bk_laporan_detail", laporan_id=laporan_id))
            row_skbb = db.execute(
                "SELECT id FROM status_skbb WHERE laporan_id=? ORDER BY id DESC LIMIT 1", (laporan_id,)
            ).fetchone()
            if row_skbb:
                db.execute(
                    """UPDATE status_skbb SET status='Direhabilitasi', catatan=?, diputuskan_oleh=?,
                       waktu_keputusan=? WHERE id=?""",
                    (catatan_rehab, session.get("user_id"), now_str(), row_skbb["id"]),
                )
                db.commit()
                catat_log("Mengajukan & menetapkan rehabilitasi status SKBB siswa", laporan_id)
                flash("Status SKBB siswa telah direhabilitasi dan tercatat di jejak audit.", "success")

        return redirect(url_for("bk_laporan_detail", laporan_id=laporan_id))

    riwayat_count = hitung_riwayat_pelaku(laporan["nama_terduga_pelaku"], laporan["kelas_terduga_pelaku"])
    tingkat_saran, sanksi_saran = saran_sanksi(riwayat_count)
    notifikasi = db.execute(
        "SELECT * FROM notifikasi_ortu WHERE laporan_id=? ORDER BY waktu_kirim DESC", (laporan_id,)
    ).fetchall()
    status_skbb_row = db.execute(
        "SELECT * FROM status_skbb WHERE laporan_id=? ORDER BY id DESC LIMIT 1", (laporan_id,)
    ).fetchone()

    pesan_default = (
        f"Yth. Orang Tua/Wali Siswa {laporan['nama_terduga_pelaku']} ({laporan['kelas_terduga_pelaku']}),\n\n"
        f"Sehubungan dengan laporan dugaan tindak perundungan yang telah diverifikasi oleh Tim TPPK "
        f"{app.config['NAMA_SEKOLAH']}, kami mengundang Bapak/Ibu untuk hadir ke sekolah guna membahas "
        f"tindak lanjut penanganan. Mohon konfirmasi kehadiran kepada Guru BK.\n\nHormat kami,\nTim TPPK Sekolah"
    )

    return render_template(
        "bk_laporan_detail.html", laporan=laporan, riwayat_count=riwayat_count,
        tingkat_saran=tingkat_saran, sanksi_saran=sanksi_saran,
        notifikasi=notifikasi, pesan_default=pesan_default,
        status_skbb_row=status_skbb_row,
        tingkat_pelanggaran_opsi=app.config["TINGKAT_PELANGGARAN_OPSI"],
    )


@app.route("/bk/edukasi", methods=["GET", "POST"])
@login_required(role="guru_bk")
def bk_edukasi():
    db = get_db()
    if request.method == "POST":
        judul = request.form.get("judul", "").strip()
        ringkasan = request.form.get("ringkasan", "").strip()
        isi = request.form.get("isi", "").strip()
        if judul and isi:
            db.execute(
                "INSERT INTO edukasi (judul, ringkasan, isi, penulis, tanggal_terbit) VALUES (?,?,?,?,?)",
                (judul, ringkasan, isi, session["nama"], datetime.now().strftime("%Y-%m-%d")),
            )
            db.commit()
            flash("Artikel edukasi baru diterbitkan.", "success")
            return redirect(url_for("bk_edukasi"))
        flash("Judul dan isi wajib diisi.", "danger")

    artikel = db.execute("SELECT * FROM edukasi ORDER BY tanggal_terbit DESC").fetchall()
    return render_template("bk_edukasi.html", artikel=artikel)


@app.route("/bk/log-akses")
@login_required(role="guru_bk")
def bk_log_akses():
    db = get_db()
    logs = db.execute(
        """SELECT log_akses.*, users.nama as nama_user, laporan.kode_tiket
           FROM log_akses
           LEFT JOIN users ON log_akses.user_id = users.id
           LEFT JOIN laporan ON log_akses.laporan_id = laporan.id
           ORDER BY log_akses.waktu DESC LIMIT 100"""
    ).fetchall()
    return render_template("bk_log_akses.html", logs=logs)


# ---------------------------------------------------------------------------
# AREA KEPALA SEKOLAH -- rekap agregat, TANPA identitas pelapor/detail sensitif
# ---------------------------------------------------------------------------
def hitung_hotspot():
    """Analitik Titik Rawan (Hotspot) perundungan berdasarkan lokasi & kategori waktu.

    Beberapa kehati-hatian statistik/privasi yang sengaja diterapkan (lihat juga README):
    - Data lokasi lama/tidak baku otomatis dikelompokkan ke 'Lainnya', bukan diabaikan.
    - Dihitung dari data SEPANJANG WAKTU (bukan cuma bulan berjalan) untuk memperbesar sampel.
    - Diberi flag 'sampel_kecil' agar dashboard tidak menyajikan persentase seolah pasti valid
      padahal jumlah datanya masih sedikit.
    - Kombinasi lokasi x waktu dengan hanya 1 kasus TIDAK ditampilkan sama sekali, dan yang di
      bawah ambang HOTSPOT_SEL_MIN_TAMPIL disamarkan angkanya -- mencegah kombinasi yang terlalu
      spesifik berpotensi mengarah ke identifikasi kasus/siswa tertentu.
    """
    db = get_db()
    opsi_lokasi_set = set(app.config["LOKASI_KEJADIAN_OPSI"])

    semua = db.execute(
        "SELECT lokasi_kejadian, kategori_waktu, tanggal_masuk FROM laporan WHERE status != 'Ditolak'"
    ).fetchall()
    total = len(semua)

    def kelompok_lokasi(nilai):
        return nilai if nilai in opsi_lokasi_set else "Lainnya"

    # --- 3 bulan terakhir (untuk deteksi tren) ---
    now = datetime.now()
    y, m = now.year, now.month
    bulan_label = []
    for i in range(2, -1, -1):
        mm, yy = m - i, y
        while mm <= 0:
            mm += 12
            yy -= 1
        bulan_label.append(f"{yy}-{mm:02d}")

    hitung_lokasi = {}
    tren_per_lokasi = {}
    for row in semua:
        lok = kelompok_lokasi(row["lokasi_kejadian"])
        hitung_lokasi[lok] = hitung_lokasi.get(lok, 0) + 1
        tren_per_lokasi.setdefault(lok, [0, 0, 0])
        bln = (row["tanggal_masuk"] or "")[:7]
        if bln in bulan_label:
            tren_per_lokasi[lok][bulan_label.index(bln)] += 1

    hotspot_list = []
    for lok, jumlah in sorted(hitung_lokasi.items(), key=lambda x: -x[1]):
        persen = round(jumlah / total * 100, 1) if total else 0
        tren = tren_per_lokasi.get(lok, [0, 0, 0])
        # Tren naik: jumlah bertambah 2 bulan berturut-turut DAN bulan ini bukan cuma 1 kasus
        # (heuristik sederhana -- bukan model statistik, sengaja dibuat konservatif)
        naik = tren[0] < tren[1] < tren[2] and tren[2] >= 2
        hotspot_list.append({"lokasi": lok, "jumlah": jumlah, "persen": persen, "tren_naik": naik})

    max_hotspot = max([h["jumlah"] for h in hotspot_list], default=0) or 1

    # --- Kombinasi lokasi x kategori waktu, dengan cell suppression ---
    kombinasi = {}
    for row in semua:
        key = (kelompok_lokasi(row["lokasi_kejadian"]), row["kategori_waktu"] or "Tidak diketahui")
        kombinasi[key] = kombinasi.get(key, 0) + 1

    ambang = app.config["HOTSPOT_SEL_MIN_TAMPIL"]
    kombinasi_list = []
    for (lok, wkt), jumlah in sorted(kombinasi.items(), key=lambda x: -x[1]):
        if jumlah < 2:
            continue  # 1 kasus saja tidak ditampilkan -- risiko terlalu spesifik/identifikasi
        kombinasi_list.append({
            "lokasi": lok, "kategori_waktu": wkt, "jumlah": jumlah,
            "tampilkan_angka": jumlah >= ambang,
        })

    return {
        "hotspot_list": hotspot_list,
        "max_hotspot": max_hotspot,
        "total_hotspot": total,
        "sampel_kecil": total < app.config["HOTSPOT_MIN_SAMPEL"],
        "hotspot_min_sampel": app.config["HOTSPOT_MIN_SAMPEL"],
        "hotspot_sel_min_tampil": ambang,
        "kombinasi_list": kombinasi_list[:5],
    }


def hitung_rekap_kepsek():
    """Kumpulkan seluruh statistik agregat untuk Kepala Sekolah -- dipakai bersama
    oleh halaman dashboard dan fitur ekspor PDF/Excel, supaya datanya selalu konsisten."""
    db = get_db()
    bulan_ini = datetime.now().strftime("%Y-%m")

    total_bulan_ini = db.execute(
        "SELECT COUNT(*) AS c FROM laporan WHERE strftime('%Y-%m', tanggal_masuk) = ?", (bulan_ini,)
    ).fetchone()["c"]

    per_status_rows = db.execute(
        "SELECT status, COUNT(*) AS c FROM laporan WHERE strftime('%Y-%m', tanggal_masuk) = ? GROUP BY status",
        (bulan_ini,),
    ).fetchall()
    per_status = [{"status": r["status"], "c": r["c"]} for r in per_status_rows]

    selesai_bulan_ini = next((r["c"] for r in per_status if r["status"] == "Selesai"), 0)
    tingkat_penyelesaian = round((selesai_bulan_ini / total_bulan_ini * 100), 1) if total_bulan_ini else 0

    bulan_target = datetime.now()
    y, m = bulan_target.year, bulan_target.month
    bulan_labels = []
    for i in range(5, -1, -1):
        mm = m - i
        yy = y
        while mm <= 0:
            mm += 12
            yy -= 1
        bulan_labels.append(f"{yy}-{mm:02d}")

    bulanan = []
    for label in bulan_labels:
        c = db.execute(
            "SELECT COUNT(*) AS c FROM laporan WHERE strftime('%Y-%m', tanggal_masuk) = ?", (label,)
        ).fetchone()["c"]
        bulanan.append({"bulan": label, "jumlah": c})
    max_bulanan = max([b["jumlah"] for b in bulanan], default=0) or 1

    per_kelas_rows = db.execute(
        """SELECT kelas_terduga_pelaku AS kelas, COUNT(*) as c FROM laporan
           WHERE status != 'Ditolak' GROUP BY kelas_terduga_pelaku ORDER BY c DESC LIMIT 5"""
    ).fetchall()
    per_kelas = [{"kelas": r["kelas"], "c": r["c"]} for r in per_kelas_rows]

    return {
        "total_bulan_ini": total_bulan_ini, "per_status": per_status,
        "tingkat_penyelesaian": tingkat_penyelesaian, "bulanan": bulanan,
        "max_bulanan": max_bulanan, "per_kelas": per_kelas, "bulan_ini": bulan_ini,
        **hitung_hotspot(),
    }


@app.route("/kepsek/dashboard")
@login_required(role="kepsek")
def kepsek_dashboard():
    stats = hitung_rekap_kepsek()
    db = get_db()
    antrean_skbb = db.execute(
        """SELECT status_skbb.*, laporan.kode_tiket, laporan.tingkat_pelanggaran,
                  laporan.sanksi, laporan.tanggal_selesai
           FROM status_skbb JOIN laporan ON status_skbb.laporan_id = laporan.id
           WHERE status_skbb.status = 'Menunggu Persetujuan'
           ORDER BY status_skbb.dibuat_pada ASC"""
    ).fetchall()
    catat_log("Melihat rekap dashboard Kepala Sekolah")
    return render_template("kepsek_dashboard.html", antrean_skbb=antrean_skbb, **stats)


@app.route("/kepsek/skbb/<int:status_skbb_id>/keputusan", methods=["POST"])
@login_required(role="kepsek")
def kepsek_keputusan_skbb(status_skbb_id):
    db = get_db()
    row = db.execute("SELECT * FROM status_skbb WHERE id=?", (status_skbb_id,)).fetchone()
    if not row:
        abort(404)

    keputusan = request.form.get("keputusan")  # 'setuju_sementara' atau 'tolak'
    catatan = request.form.get("catatan", "").strip()
    if not catatan:
        flash("Alasan keputusan wajib diisi -- akan tercatat di jejak audit.", "danger")
        return redirect(url_for("kepsek_dashboard"))

    status_baru = "Disetujui Sementara" if keputusan == "setuju_sementara" else "Ditolak"
    db.execute(
        """UPDATE status_skbb SET status=?, catatan=?, diputuskan_oleh=?, waktu_keputusan=?
           WHERE id=?""",
        (status_baru, catatan, session.get("user_id"), now_str(), status_skbb_id),
    )
    db.commit()
    catat_log(
        f"Kepsek: {status_baru} pencetakan SKBB untuk {row['nama_siswa']} ({row['kelas_siswa']})",
        row["laporan_id"],
    )
    flash(f"Keputusan tercatat: {status_baru}.", "success")
    return redirect(url_for("kepsek_dashboard"))


@app.route("/kepsek/rekap/export.pdf")
@login_required(role="kepsek")
def kepsek_export_pdf():
    stats = hitung_rekap_kepsek()
    buf = buat_pdf_rekap(stats, app.config["NAMA_SEKOLAH"])
    catat_log("Mengunduh rekap bulanan (PDF)")
    nama_file = f"rekap-bulanan-{stats['bulan_ini']}.pdf"
    return send_file(buf, as_attachment=True, download_name=nama_file, mimetype="application/pdf")


@app.route("/kepsek/rekap/export.xlsx")
@login_required(role="kepsek")
def kepsek_export_excel():
    stats = hitung_rekap_kepsek()
    buf = buat_excel_rekap(stats, app.config["NAMA_SEKOLAH"])
    catat_log("Mengunduh rekap bulanan (Excel)")
    nama_file = f"rekap-bulanan-{stats['bulan_ini']}.xlsx"
    return send_file(buf, as_attachment=True, download_name=nama_file,
                      mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


# ---------------------------------------------------------------------------
# AREA TATA USAHA (TU) -- HANYA bisa cek status SKBB, TIDAK BISA lihat detail kasus
# ---------------------------------------------------------------------------
@app.route("/tu/cek-skbb", methods=["GET", "POST"])
@login_required(role="tu")
def tu_dashboard():
    hasil = None
    dicari = False
    if request.method == "POST":
        dicari = True
        nama = request.form.get("nama_siswa", "").strip()
        kelas = request.form.get("kelas_siswa", "").strip()
        if nama and kelas:
            hasil = cek_status_skbb(nama, kelas)
            catat_log(f"TU mengecek status SKBB untuk '{nama} - {kelas}'")
    kelas_list = get_db().execute("SELECT nama_kelas FROM kelas ORDER BY nama_kelas").fetchall()
    return render_template("tu_dashboard.html", hasil=hasil, dicari=dicari, kelas_list=kelas_list)


# ---------------------------------------------------------------------------
# Error handlers
# ---------------------------------------------------------------------------
@app.errorhandler(403)
def forbidden(e):
    return render_template("error.html", kode=403, pesan="Kamu tidak punya akses ke halaman ini."), 403


@app.errorhandler(404)
def not_found(e):
    return render_template("error.html", kode=404, pesan="Halaman tidak ditemukan."), 404


@app.errorhandler(413)
def file_terlalu_besar(e):
    batas_mb = app.config["MAX_CONTENT_LENGTH"] // (1024 * 1024)
    return render_template(
        "error.html", kode=413,
        pesan=f"File yang kamu unggah terlalu besar (maksimal {batas_mb} MB). Silakan kembali dan coba lagi dengan file yang lebih kecil, atau kirim laporan tanpa lampiran bukti terlebih dahulu."
    ), 413


@app.errorhandler(500)
def internal_error(e):
    # SENGAJA tidak menampilkan detail teknis/traceback ke pengguna -- selain
    # membingungkan, itu juga berisiko membocorkan informasi internal sistem.
    return render_template(
        "error.html", kode=500,
        pesan="Terjadi kesalahan pada sistem. Laporan yang sedang kamu tulis mungkin belum terkirim -- silakan coba lagi. Jika ini terus berulang, hubungi Guru BK secara langsung."
    ), 500


if __name__ == "__main__":
    if not os.path.exists(app.config["DATABASE"]):
        print("Database belum ada. Jalankan dulu: python init_db.py")
    app.run(debug=True, host="0.0.0.0", port=5000)
